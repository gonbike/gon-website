---
title: "mg_casecmp()"
decl_name: "mg_casecmp"
symbol_kind: "func"
signature: |
  int mg_casecmp(const char *s1, const char *s2);
---

Cross-platform version of `strcasecmp()`. 

