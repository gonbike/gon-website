---
title: "MQTT Server API reference"
symbol_kind: "intro"
decl_name: "mqtt_server.h"
items:
  - { name: mg_mqtt_broker_init.md }
  - { name: mg_mqtt_broker.md }
  - { name: mg_mqtt_next.md }
  - { name: struct_mg_mqtt_session.md }
  - { name: struct_mg_mqtt_broker.md }
---



