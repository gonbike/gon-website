---
title: "mg_mqtt_broker_init()"
decl_name: "mg_mqtt_broker_init"
symbol_kind: "func"
signature: |
  void mg_mqtt_broker_init(struct mg_mqtt_broker *brk, void *user_data);
---

Initialises a MQTT broker. 

