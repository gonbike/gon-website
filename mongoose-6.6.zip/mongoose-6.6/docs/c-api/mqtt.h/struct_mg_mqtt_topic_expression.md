---
title: "struct mg_mqtt_topic_expression"
decl_name: "struct mg_mqtt_topic_expression"
symbol_kind: "struct"
signature: |
  struct mg_mqtt_topic_expression {
    const char *topic;
    uint8_t qos;
  };
---

puback 

