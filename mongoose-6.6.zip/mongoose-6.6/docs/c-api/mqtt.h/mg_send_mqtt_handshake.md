---
title: "mg_send_mqtt_handshake()"
decl_name: "mg_send_mqtt_handshake"
symbol_kind: "func"
signature: |
  void mg_send_mqtt_handshake(struct mg_connection *nc, const char *client_id);
---

Sends an MQTT handshake. 

