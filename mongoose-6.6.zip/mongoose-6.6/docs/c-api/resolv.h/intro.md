---
title: "API reference"
symbol_kind: "intro"
decl_name: "resolv.h"
items:
  - { name: mg_resolve_async.md }
  - { name: mg_resolve_async_opt.md }
  - { name: mg_resolve_from_hosts_file.md }
  - { name: struct_mg_resolve_async_opts.md }
---



