---
title: "URI"
symbol_kind: "intro"
decl_name: "uri.h"
items:
  - { name: mg_parse_uri.md }
---



